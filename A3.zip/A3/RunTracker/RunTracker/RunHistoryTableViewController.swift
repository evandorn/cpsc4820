//
//  RunHistoryTableViewController.swift
//  RunTracker
//
//  Created by Evan Dorn on 9/24/15.
//  Copyright (c) 2015 Evan Dorn. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class RunHistoryTableViewController: UITableViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var runHistroyTableView: UITableView!
    
    // var runCount = 0
    var appDelegate = (UIApplication.sharedApplication().delegate as! AppDelegate)
    var context: NSManagedObjectContext! 
    var totalEntries: Int = 0
    
    var runs = [NSManagedObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        runHistroyTableView.reloadData()
        
        self.navigationItem.rightBarButtonItem = self.editButtonItem()
        title = "Run History"                                           // Set the title in Code
        var fetchRequest = NSFetchRequest(entityName: "Run")
        fetchRequest.returnsObjectsAsFaults = false
        
        totalEntries = context!.countForFetchRequest(fetchRequest, error: nil)
        
        print("Number of Entries:  ")
        print(totalEntries)
        
      }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    override func viewDidAppear(animated: Bool) {
        self.tableView.reloadData()
    }


    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return totalEntries
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "Default")
        
        
        var appDel = (UIApplication.sharedApplication().delegate as! AppDelegate)
        var context = appDel.managedObjectContext
        
        var request = NSFetchRequest(entityName: "Run")
        request.returnsObjectsAsFaults = false
        
        var results: NSArray = context!.executeFetchRequest(request, error: nil)!
        
        //Get contents and put into cell
        
        var runData = results[indexPath.row] as! Run
        
        var distanceString = (String)(_cocoaString: runData.distance)
        var durationString = (String)(_cocoaString: runData.duration)
        var timeString = (String)(_cocoaString: runData.timestamp)
        
        cell.detailTextLabel?.text = "Distance: " + distanceString + " " + durationString + " " + timeString
        
        return cell
    }
    
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        //delete obj from entity and remove from list
        
        let cell: UITableViewCell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "Default")
        
        
        var appDel = (UIApplication.sharedApplication().delegate as! AppDelegate)
        var context = appDel.managedObjectContext
        
        var request = NSFetchRequest(entityName: "Run")
        request.returnsObjectsAsFaults = false
        
        var results: NSArray = context!.executeFetchRequest(request, error: nil)!
        
        context!.deleteObject(results[indexPath.row] as! NSManagedObject)
        context!.save(nil)
        totalEntries = totalEntries - 1
        
        runHistroyTableView.reloadData()
        
    }

}